#include <stdio.h>

int main(void)
{
  int i;
  
  i=511;

  printf("Value= %d\n",*(int *)());

  return 0;
}
