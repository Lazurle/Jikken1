#include <stdio.h>

int main(void)
{
  int i;
  
  i=511;

  printf("Value=   \n",  );
  printf("Address=   \n",  );
  
  return 0;
}
