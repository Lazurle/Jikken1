class Rectangle{
    
    int x;
    int y;
    int height;
    int width;
    
    Rectangle(int x,int y,int height,int width){
        this.x=x;
        this.y=y;
        this.height=height;
        this.width=width;
    }
}